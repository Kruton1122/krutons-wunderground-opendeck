#!/usr/bin/env node
const https = require("https");
const net = require("net");
const crypto = require("crypto");

let registeredContexts = {};
let refreshTimers = {};
let wsSocket = null;
let sendBuffer = [];
let connected = false;

const args = process.argv.slice(2);
const argMap = {};
for (let i = 0; i < args.length; i += 2) argMap[args[i]] = args[i + 1];
const port = parseInt(argMap["-port"]);
const pluginUUID = argMap["-pluginUUID"];
if (!port || !pluginUUID) process.exit(1);

// ── WebSocket client ──────────────────────────────────────────────────────────
function wsConnect(port, onOpen, onMessage) {
  const socket = net.createConnection(port, "127.0.0.1");
  const key = crypto.randomBytes(16).toString("base64");
  let handshakeDone = false;
  let buf = Buffer.alloc(0);
  socket.on("connect", () => {
    socket.write(`GET / HTTP/1.1\r\nHost: 127.0.0.1:${port}\r\nUpgrade: websocket\r\nConnection: Upgrade\r\nSec-WebSocket-Key: ${key}\r\nSec-WebSocket-Version: 13\r\n\r\n`);
  });
  socket.on("data", (chunk) => {
    buf = Buffer.concat([buf, chunk]);
    if (!handshakeDone) {
      const idx = buf.indexOf("\r\n\r\n");
      if (idx === -1) return;
      handshakeDone = true;
      buf = buf.slice(idx + 4);
      onOpen(socket);
    }
    while (buf.length >= 2) {
      let payLen = buf[1] & 0x7f, offset = 2;
      if (payLen === 126) { if (buf.length < 4) break; payLen = buf.readUInt16BE(2); offset = 4; }
      else if (payLen === 127) { if (buf.length < 10) break; payLen = Number(buf.readBigUInt64BE(2)); offset = 10; }
      if (buf.length < offset + payLen) break;
      if ((buf[0] & 0x0f) === 1) onMessage(buf.slice(offset, offset + payLen).toString());
      buf = buf.slice(offset + payLen);
    }
  });
  socket.on("error", (e) => console.error("WS:", e.message));
  socket.sendText = function(text) {
    const payload = Buffer.from(text);
    const len = payload.length;
    const mask = crypto.randomBytes(4);
    let header;
    if (len < 126) header = Buffer.from([0x81, 0x80 | len]);
    else if (len < 65536) { header = Buffer.alloc(4); header[0]=0x81; header[1]=0xfe; header.writeUInt16BE(len,2); }
    else { header = Buffer.alloc(10); header[0]=0x81; header[1]=0xff; header.writeBigUInt64BE(BigInt(len),2); }
    header[1] |= 0x80;
    const masked = Buffer.alloc(payload.length);
    for (let i = 0; i < payload.length; i++) masked[i] = payload[i] ^ mask[i % 4];
    socket.write(Buffer.concat([header, mask, masked]));
  };
  return socket;
}

wsSocket = wsConnect(port,
  (socket) => {
    connected = true;
    send({ event: "registerPlugin", uuid: pluginUUID });
    for (const msg of sendBuffer) socket.sendText(JSON.stringify(msg));
    sendBuffer = [];
  },
  (raw) => {
    let msg; try { msg = JSON.parse(raw); } catch { return; }
    const { event, context, payload } = msg;
    if (event === "willAppear") {
      registeredContexts[context] = payload?.settings || {};
      fetchAndUpdate(context);
      scheduleRefresh(context);
    }
    if (event === "willDisappear") {
      delete registeredContexts[context];
      clearRefresh(context);
    }
    if (event === "didReceiveSettings") {
      registeredContexts[context] = payload?.settings || {};
      fetchAndUpdate(context);
      scheduleRefresh(context);
    }
    if (event === "keyUp") fetchAndUpdate(context);
  }
);

// ── Per-context refresh timers ────────────────────────────────────────────────
function scheduleRefresh(context) {
  clearRefresh(context);
  const s = registeredContexts[context] || {};
  const mins = parseInt(s.refreshInterval ?? 5);
  if (mins <= 0) return;
  refreshTimers[context] = setInterval(() => fetchAndUpdate(context), mins * 60 * 1000);
}

function clearRefresh(context) {
  if (refreshTimers[context]) { clearInterval(refreshTimers[context]); delete refreshTimers[context]; }
}

// ── Condition detection ───────────────────────────────────────────────────────
function getCondition(obs) {
  const precipRate = obs.imperial?.precipRate || obs.metric?.precipRate || 0;
  const temp = obs.imperial?.temp ?? obs.metric?.temp ?? 50;
  const { humidity, solarRadiation, uv } = obs;
  const hour = new Date(obs.obsTimeLocal).getHours();
  const isNight = hour < 6 || hour >= 20;
  if (precipRate > 0 && temp <= 33) return "snow";
  if (precipRate > 0) return "rain";
  if (isNight) return "night";
  if (solarRadiation < 50 && uv < 1) return "cloudy";
  if (solarRadiation < 200 || humidity > 75) return "partlycloudy";
  return "sunny";
}

// ── SVG builder ───────────────────────────────────────────────────────────────
function makeSVG(condition, tempStr, humidity, precipRate, location, settings) {
  const bgStyle = settings.bgStyle || "weather";
  const tempSize = parseInt(settings.tempSize) || 26;
  const showHumidity = (settings.showHumidity || "yes") === "yes";
  const showPrecip = (settings.showPrecip || "yes") === "yes" && precipRate > 0;
  const showLocation = (settings.showLocation || "yes") === "yes" && location;
  const showWeatherIcon = bgStyle === "weather";

  const rows = 1 + (showHumidity ? 1 : 0) + (showPrecip ? 1 : 0) + (showLocation ? 1 : 0);
  const subSize = Math.max(10, Math.min(13, 32 - rows * 2));
  const lineH = subSize + 5;
  const totalTextH = tempSize + (rows - 1) * lineH + 4;
  const iconH = showWeatherIcon ? 70 : 0;
  const availH = 144 - iconH;
  const textBlockTop = iconH + (availH - totalTextH) / 2 + tempSize;

  let curY = Math.round(textBlockTop);
  const tempY = curY; curY += lineH;
  const humidY = curY; curY += lineH;
  const precipY = curY; curY += lineH;
  const locY = curY;

  const weatherBgs = {
    sunny:        ["#1a6fc4","#56c1ff"],
    partlycloudy: ["#2980b9","#6dd5fa"],
    cloudy:       ["#636e72","#b2bec3"],
    rain:         ["#2c3e50","#4a6fa5"],
    snow:         ["#a8c8e8","#dfe6e9"],
    night:        ["#0a0a2e","#1a1a4e"],
  };
  const fixedBgs = { black: ["#000","#000"], dark: ["#1a1a1a","#2d2d2d"] };
  let bgColors;
  if (bgStyle === "custom") { const c = settings.bgColor||"#1a1a2e"; bgColors=[c,c]; }
  else if (fixedBgs[bgStyle]) bgColors = fixedBgs[bgStyle];
  else bgColors = weatherBgs[condition] || weatherBgs.cloudy;

  let txtColor = "white";
  if (settings.textColor === "black") txtColor = "#111";
  else if (settings.textColor === "custom") txtColor = settings.customTextColor || "#fff";
  else {
    const c = bgColors[0].replace("#","");
    const r=parseInt(c.slice(0,2)||"00",16), g=parseInt(c.slice(2,4)||"00",16), b=parseInt(c.slice(4,6)||"00",16);
    txtColor = (0.299*r + 0.587*g + 0.114*b)/255 > 0.55 ? "#111" : "white";
  }

  const icons = {
    sunny: `<circle cx="72" cy="36" r="15" fill="#FFD700"/>
      <g stroke="#FFD700" stroke-width="2.5" stroke-linecap="round">
        <line x1="72" y1="12" x2="72" y2="6"/><line x1="72" y1="60" x2="72" y2="66"/>
        <line x1="48" y1="36" x2="42" y2="36"/><line x1="96" y1="36" x2="102" y2="36"/>
        <line x1="55" y1="19" x2="50" y2="14"/><line x1="89" y1="53" x2="94" y2="58"/>
        <line x1="89" y1="19" x2="94" y2="14"/><line x1="55" y1="53" x2="50" y2="58"/>
      </g>`,
    partlycloudy: `<circle cx="55" cy="32" r="13" fill="#FFD700"/>
      <ellipse cx="78" cy="50" rx="26" ry="15" fill="white" opacity="0.95"/>
      <ellipse cx="56" cy="54" rx="19" ry="13" fill="white" opacity="0.95"/>
      <ellipse cx="92" cy="54" rx="16" ry="12" fill="white" opacity="0.95"/>`,
    cloudy: `<ellipse cx="72" cy="42" rx="30" ry="18" fill="white" opacity="0.85"/>
      <ellipse cx="50" cy="48" rx="22" ry="15" fill="white" opacity="0.85"/>
      <ellipse cx="90" cy="48" rx="20" ry="14" fill="white" opacity="0.85"/>
      <ellipse cx="72" cy="56" rx="34" ry="14" fill="white" opacity="0.9"/>`,
    rain: `<ellipse cx="72" cy="34" rx="28" ry="16" fill="#95a5a6"/>
      <ellipse cx="50" cy="40" rx="20" ry="13" fill="#95a5a6"/>
      <ellipse cx="88" cy="40" rx="18" ry="12" fill="#7f8c8d"/>
      <ellipse cx="72" cy="46" rx="32" ry="12" fill="#7f8c8d"/>
      <g stroke="#74b9ff" stroke-width="2.5" stroke-linecap="round">
        <line x1="50" y1="58" x2="44" y2="68"/><line x1="63" y1="60" x2="57" y2="70"/>
        <line x1="76" y1="58" x2="70" y2="68"/><line x1="89" y1="60" x2="83" y2="70"/>
        <line x1="102" y1="58" x2="96" y2="68"/>
      </g>`,
    snow: `<ellipse cx="72" cy="34" rx="28" ry="16" fill="white" opacity="0.9"/>
      <ellipse cx="50" cy="40" rx="20" ry="13" fill="white" opacity="0.9"/>
      <ellipse cx="88" cy="40" rx="18" ry="12" fill="white" opacity="0.9"/>
      <ellipse cx="72" cy="46" rx="32" ry="12" fill="white" opacity="0.95"/>
      <g fill="white" font-size="13" text-anchor="middle">
        <text x="46" y="64">❄</text><text x="72" y="68">❄</text><text x="98" y="64">❄</text>
      </g>`,
    night: `<circle cx="76" cy="32" r="14" fill="#f1c40f"/>
      <circle cx="85" cy="26" r="11" fill="#0a0a2e"/>
      <circle cx="36" cy="20" r="2" fill="white"/><circle cx="114" cy="14" r="1.5" fill="white"/>
      <circle cx="98" cy="26" r="1" fill="white"/><circle cx="24" cy="40" r="1.5" fill="white"/>
      <circle cx="122" cy="44" r="1" fill="white"/>`,
  };

  const unitLabel = (settings.units||"e") === "m" ? "°C" : "°F";
  const precipUnit = (settings.units||"e") === "m" ? "mm/h" : '"/h';

  // Truncate location name to fit
  const locStr = location ? (location.length > 12 ? location.slice(0,11)+"…" : location) : "";

  return `<svg xmlns="http://www.w3.org/2000/svg" width="144" height="144" viewBox="0 0 144 144">
  <defs>
    <linearGradient id="bg" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0%" stop-color="${bgColors[0]}"/>
      <stop offset="100%" stop-color="${bgColors[1]}"/>
    </linearGradient>
    <filter id="sh"><feDropShadow dx="0" dy="1" stdDeviation="1" flood-opacity="0.6"/></filter>
  </defs>
  <rect width="144" height="144" fill="url(#bg)"/>
  ${showWeatherIcon ? (icons[condition]||"") : ""}
  <text x="72" y="${tempY}" text-anchor="middle" font-family="Arial" font-weight="bold" font-size="${tempSize}" fill="${txtColor}" filter="url(#sh)">${tempStr}${unitLabel}</text>
  ${showHumidity ? `<text x="72" y="${humidY}" text-anchor="middle" font-family="Arial" font-size="${subSize}" fill="${txtColor}" opacity="0.9" filter="url(#sh)">💧 ${humidity}%</text>` : ""}
  ${showPrecip ? `<text x="72" y="${showHumidity ? precipY : humidY}" text-anchor="middle" font-family="Arial" font-size="${subSize}" fill="${txtColor}" opacity="0.85" filter="url(#sh)">🌧 ${precipRate}${precipUnit}</text>` : ""}
  ${showLocation ? `<text x="72" y="${locY}" text-anchor="middle" font-family="Arial" font-size="${Math.max(9, subSize-1)}" fill="${txtColor}" opacity="0.75" filter="url(#sh)">${locStr}</text>` : ""}
</svg>`;
}

// ── Fetch ─────────────────────────────────────────────────────────────────────
function fetchAndUpdate(context) {
  const s = registeredContexts[context] || {};
  const { apiKey, stationId, units } = s;
  if (!apiKey || !stationId) { setTitle(context, !stationId ? "Set\nStation" : "Set\nAPI Key"); return; }
  const u = units || "e";
  const url = `https://api.weather.com/v2/pws/observations/current?stationId=${encodeURIComponent(stationId)}&format=json&units=${u}&apiKey=${encodeURIComponent(apiKey)}`;
  https.get(url, (res) => {
    let data = "";
    res.on("data", (c) => data += c);
    res.on("end", () => {
      try {
        const obs = JSON.parse(data)?.observations?.[0];
        if (!obs) { setTitle(context, "No Data"); return; }
        const imp = obs.imperial||{}, met = obs.metric||{};
        const temp = u === "m" ? met.temp : imp.temp;
        const precipRate = u === "m" ? (met.precipRate||0) : (imp.precipRate||0);
        const humidity = obs.humidity;
        const location = obs.neighborhood || obs.stationID || "";
        if (temp == null) { setTitle(context, "No Temp"); return; }
        const condition = getCondition(obs);
        const svg = makeSVG(condition, temp, humidity, precipRate, location, s);
        send({ event: "setImage", context, payload: { image: "data:image/svg+xml;base64," + Buffer.from(svg).toString("base64"), target: 0 } });
        send({ event: "setTitle", context, payload: { title: "", target: 0 } });
      } catch(e) { console.error(e); setTitle(context, "Error"); }
    });
  }).on("error", () => setTitle(context, "Error"));
}

function setTitle(ctx, t) { send({ event: "setTitle", context: ctx, payload: { title: t, target: 0 } }); }
function send(obj) {
  if (connected && wsSocket) wsSocket.sendText(JSON.stringify(obj));
  else sendBuffer.push(obj);
}
